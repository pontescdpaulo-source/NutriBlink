---
name: NutriBlink Institutional Design System
colors:
  surface: '#f8f9ff'
  surface-dim: '#c4dcfd'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef4ff'
  surface-container: '#e5efff'
  surface-container-high: '#dbe9ff'
  surface-container-highest: '#d1e4ff'
  on-surface: '#011d35'
  on-surface-variant: '#444651'
  inverse-surface: '#19324b'
  inverse-on-surface: '#e9f1ff'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#3e2400'
  on-tertiary: '#ffffff'
  tertiary-container: '#5c3800'
  on-tertiary-container: '#ef9900'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#011d35'
  surface-variant: '#d1e4ff'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  mono-data:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

The design system establishes a civic-tech modern SaaS identity engineered for public school nutrition management, compliance monitoring, and state education integrations (SIEPE). It targets state coordinators, school principals, municipal nutritionists, and kitchen warehouse operators. 

The visual personality combines the institutional trust, authority, and sobriety expected by governmental audit bodies with the responsiveness, clarity, and ergonomic ease of contemporary productivity software. The interface avoids bureaucratic clutter and avoids playful or childish school tropes; it presents food security, supply chain tracking, and budget execution with rigorous precision.

### Design Movement: Modern Civic SaaS
- **Clean Structure**: High clarity, uncluttered visual rhythm, and explicit hierarchy tailored for dense data display (inventories, batch tracking, caloric compliance, delivery rosters).
- **Functional Cleanliness**: Pristine off-white foundation surfaces (`#F8FAFC`), deliberate whitespace, high-contrast text metrics, and subtle 1px border dividers to ground visual boundaries under varied field lighting.
- **Operational Confidence**: Color used functionally rather than decoratively. Statuses (normal, attention, critical, synchronized) drive rapid decision-making across high-stress school kitchen environments and high-level administrative dashboards.

## Colors

The palette aligns governmental accountability with vitality, health, and logistical urgency.

### Primary Palette (Institutional Trust & Navigation)
- **Deep Navy (`#0F2942`)**: Main text, sidebar chrome, executive data headers, and anchoring elements.
- **Cobalt Blue (`#1E3A8A`)**: Primary institutional brand tone, primary buttons, active navigation markers, and authoritative callouts.
- **Vibrant Blue (`#2563EB` / `#3B82F6`)**: Interactive links, focus outlines, secondary action indicators, and mobile interactive controls.

### Semantic & Operational Accents
- **Emerald Green (`#10B981` / `#059669`)**: Freshness, nutritional adequacy, inventory balanced, and "Sincronizado SIEPE" state.
- **Amber Warning (`#F59E0B`)**: FEFO alerts (First-Expired, First-Out), items approaching expiration within 15–30 days, pending approval, and "Revisar".
- **Critical Red (`#EF4444`)**: Expired stock, severe stockout risk, non-compliance with PNAE dietary thresholds, and unhandled sync errors.

### Background & Surface Hierarchy
- **Canvas Base (`#F8FAFC`)**: Base view canvas ensuring minimal glare during prolonged administrative work.
- **Subtle Well (`#F1F5F9`)**: Neutral input backgrounds, table headers, and structural rails.
- **Card Surface (`#FFFFFF`)**: Content elevation cards.
- **Borders (`#E2E8F0`)**: Low-contrast boundary strokes maintaining crisp layout geometry without visual noise.

## Typography

The dual-type strategy couples **Plus Jakarta Sans** for headlines and structural titles with **Inter** for dense tabular screens, form controls, and badge microcopy.

- **Plus Jakarta Sans**: Injects contemporary civic polish and friendliness into headings, balancing the strict nature of audit platforms with humane warmth.
- **Inter**: Maximizes optical legibility at 11px to 14px inside data-heavy datagrids, logistics manifests, batch expiration tables, and mobile inventory forms.
- **Tabular Numerals**: Numerical values (weights, units, nutritional percentages, and dates) must enforce font feature settings (`tnum`) in Inter to align vertically across inventory reports and balance sheets.
- **Micro-labels**: All small status indicators use `label-sm` with a slight uppercase styling or emphasized weight (`600`) to guarantee rapid scannability on low-end mobile devices used in distribution centers.

## Layout & Spacing

The layout utilizes an 8-point baseline grid adapted for high-density administrative workloads on desktop and large touch-target ergonomics on mobile.

### Breakpoints & Layout Models
- **Desktop (>= 1280px)**: 12-column fluid grid, `margin`: 2rem (32px), `gutter`: 1.5rem (24px). Sidebar fixed at 260px; primary workspace stretches with a max-width limit of 1600px to maintain legible line lengths in inventory sheets.
- **Tablet / Laptop (768px – 1279px)**: 8-column layout, `margin`: 1.5rem (24px), `gutter`: 1rem (16px). Sidebar collapses to a 64px compact icon rail.
- **Mobile (< 768px)**: 4-column fluid layout, `margin-mobile`: 1rem (16px), `gutter-mobile`: 0.75rem (12px). Full-bleed layout with bottom navigation bar for field inventory checks.

### Spacing Scale Rules
- `space-xs` (4px): Micro gaps between icons and badge text, inline rating tags, and indicator dots.
- `space-sm` (8px): Form input inner paddings, button internal horizontal spacing, and segmented control segments.
- `space-md` (16px): Standard gap between fields in data entry forms, inner padding for data cells, and card header separation.
- `space-lg` (24px): Card interior padding, metric summary cluster margins, and modal dialog bodies.
- `space-xl` (32px): Vertical division between dashboard analytical blocks, data table containers, and page title blocks.

## Elevation & Depth

This design system avoids high-blur, floaty skeuomorphic drops. It relies on crisp surface layering with light ambient shadows and structural micro-borders (`#E2E8F0`) to clearly communicate interactive states without distraction.

### Elevation Levels

- **Level 0 (Flat Canvas)**: `#F8FAFC` base background. Zero shadow. Used for page backgrounds and disabled container blocks.
- **Level 1 (Card & Section Containers)**: `#FFFFFF` surface with a continuous 1px outline of `#E2E8F0` and subtle ambient drop: `box-shadow: 0 1px 3px 0 rgba(15, 41, 66, 0.05), 0 1px 2px -1px rgba(15, 41, 66, 0.05)`.
- **Level 2 (Hover States & Contextual Popovers)**: `#FFFFFF` surface, 1px border `#CBD5E1`, with dynamic lift: `box-shadow: 0 4px 6px -1px rgba(15, 41, 66, 0.07), 0 2px 4px -2px rgba(15, 41, 66, 0.05)`.
- **Level 3 (Modals, Overlays, and Drawers)**: Pure white `#FFFFFF` surface with higher projection over a backdrop tint (`rgba(15, 41, 66, 0.4)`): `box-shadow: 0 20px 25px -5px rgba(15, 41, 66, 0.1), 0 8px 10px -6px rgba(15, 41, 66, 0.08)`.

### SIEPE Sync State Elevation
Cards containing active real-time synchronization or critical FEFO warnings utilize a 3px left-border anchor (e.g., `#10B981` for synchronized, `#EF4444` for critical batch expiry) to provide immediate peripheral cues without raising the z-index.

## Shapes

The design system implements a controlled, modern curvature strategy that strikes a balance between civic authority and software friendliness.

- **Base Radius (`rounded-md` / 0.5rem - 8px)**: Standard UI controls, form inputs, button components, dropdown menus, and nested table cells.
- **Container Radius (`rounded-lg` / 1rem - 16px)**: Primary operational cards, metric summaries, and desktop modal dialogue windows.
- **Feature Cards (`rounded-xl` / 1.5rem - 24px)**: Highlighted hero metrics, onboarding containers, and bottom-sheet drawers on mobile views.
- **Pill Form (`rounded-full` / 9999px)**: Strictly reserved for status badges, tags, filter chips, and user avatars. Avoid pill-shaped action buttons to preserve an enterprise software profile.

## Components

### Buttons
- **Primary**: Solid Cobalt (`#1E3A8A`) background, white text, 8px radius. Hover: `#172E6D`. Active: `#0F2942`. Focus ring: 2px offset with `#3B82F6`.
- **Secondary**: `#FFFFFF` background, `#1E3A8A` text, 1px solid border (`#CBD5E1`). Hover: `#F1F5F9`.
- **Danger (Critical Action)**: Solid Crimson (`#EF4444`) with white text for irreversible inventory disposals or school unlinking.
- **Mobile Target**: Mobile actions enforce a minimum height of 48px to accommodate kitchen warehouse operators.

### Status Badges & Chips
Status badges use a pill shape, `label-sm` typography, and paired light/dark color tokens:
- **Normal / Adequate**: Light green (`#ECFDF5`) background, `#047857` text, with a 6px solid emerald dot.
- **Sincronizado SIEPE**: Clean tint (`#F0FDF4`), `#15803D` text, paired with a checkmark or dual-arrow sync icon.
- **Atenção (FEFO 15-30 Dias)**: Light amber (`#FFFBEB`) background, `#B45309` text.
- **Crítico / Vencido**: Light red (`#FEF2F2`) background, `#B91C1C` text, indicating urgent quarantine or consumption.
- **Revisar / Pendente**: Soft slate (`#F1F5F9`) background, `#475569` text.
- **Identificado**: Soft blue (`#EFF6FF`) background, `#1D4ED8` text.

### Cards
- Standard layout uses pure white background, 1px `#E2E8F0` border, 16px padding, and 16px border-radius (`rounded-lg`).
- Data dashboard cards place the label in uppercase `label-sm` slate (`#64748B`), the metric value in `headline-lg` (`#0F2942`), and the trend or sync indicator at the bottom edge.

### Input Fields
- White background (`#FFFFFF`) with a 1px border (`#CBD5E1`), 8px border-radius, and 12px horizontal padding.
- Focused: Border turns to `#2563EB` accompanied by an ambient 3px box-shadow halo (`rgba(37, 99, 235, 0.15)`).
- Error state: 1px border in `#EF4444`, helper copy rendered in `body-sm` red below field.

### Lists & Data Tables
- Header row styled with `#F8FAFC`, uppercase `label-xs` typography, and low-contrast bottom border (`#E2E8F0`).
- Alternating row zebra banding is omitted in favor of clean 1px borders and a subtle hover highlight (`#F8FAFC`).
- Numerical columns right-align with monospace tabular figures (`font-variant-numeric: tabular-nums`).

### Specialized Domain Components
- **FEFO Expiration Meter**: A compact segmented progress bar showing batch shelf life (Green > Yellow > Red) with remaining day counts.
- **SIEPE Integration Indicator**: Dedicated header badge showing last sync timestamp, auto-refresh state, and quick trigger button for manual reconciliation.